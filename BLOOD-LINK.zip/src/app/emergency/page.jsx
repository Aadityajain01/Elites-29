"use client";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import Footer from "@/components/Footer";

const Emergency = () => {
  return (
    <div>
      <Navbar />

      <div>
        <div className="container w-[1000px] m-auto mt-10 text-center">
          <div className="flex items-center justify-center">
            <Input
              placeholder="Enter city Name...  "
              className="text-red-700 m-4"
            />
            <Button type="submit" className="bg-red-700 text-white">
              {" "}<Card className="rounded-lg mr-5 shadow-lg border-none bg-red-700">
             
             </Card>
              Search
            </Button>
          </div   >
            <div className="flex flex-col items-center gap-10" >
            <h1 className="text-red-700 font-bold text-2xl " >Blood banks in City</h1>
                <Card className="bg-red-700 text-white p-4 " >
                    <CardTitle>
                        City Name
                    </CardTitle>
                    <p>
                        Blood Bank Name
                    </p>
                </Card>
            </div>
        </div>
      </div>
-
      
      
      <Footer  ></Footer>
    </div>
  );
};

export default Emergency;
