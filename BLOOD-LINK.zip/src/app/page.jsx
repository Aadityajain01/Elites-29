import Form from '@/components/Form'
import Home from '@/components/Home'
import React from 'react'

const page = () => {
  return (
    <div>
      <Home></Home>
   </div>
  )
}

export default page
