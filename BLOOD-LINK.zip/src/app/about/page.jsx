"use client";

import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";

const Infor = (props) => {
  return (
    <div>
      <Navbar />
      <div className="flex flex-col items-center justify-center gap-10" >
        <h1 className="font-bold text-red-700 text-6xl" >About us</h1>

        <div className="w-[1280px] mx-auto gap-4 flex-1" >
          <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Est exercitationem incidunt dolore illo inventore a enim expedita at sunt itaque! Impedit doloribus officiis saepe excepturi aut cum. Dolorum adipisci sit, sint unde odit neque eum, ullam tempore officia ab totam voluptates animi quidem quibusdam ut minus. Voluptate reiciendis id dolore obcaecati odit maiores suscipit dolores aut adipisci consequatur! Quas fugit deleniti ullam magni nemo, quos quam? Iusto sequi sint sit, est ullam dolor maiores suscipit, aliquam nobis, temporibus praesentium obcaecati saepe blanditiis fuga at eius incidunt? Nostrum placeat porro quas itaque iure doloribus tempora id, enim optio, consequatur nam quos quod culpa exercitationem sapiente omnis! Nihil ipsum in iusto. Ipsum molestiae architecto doloribus vero nihil aspernatur ipsam, velit eius perspiciatis error dicta placeat. A amet inventore, veritatis quis asperiores deserunt quasi saepe! Saepe nulla odit velit quia dolorem enim non excepturi nihil perspiciatis voluptatem quod commodi incidunt neque debitis, blanditiis laboriosam voluptate adipisci vel delectus ipsum optio tempora, corrupti minus. Ullam, sapiente ipsam. Itaque nemo laboriosam molestiae quidem cumque eos vel nihil, consequatur eligendi, culpa fugit fuga dolorum soluta quae consectetur repellendus quis. Assumenda, necessitatibus totam qui fuga nisi, magni saepe ullam soluta possimus quis, amet enim mollitia laborum. Odio.          </p>

            <hr />

            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit. Rerum recusandae ipsa, cum corrupti est nostrum numquam commodi, voluptate nobis quisquam, in delectus ratione reprehenderit suscipit? Veniam illum sed molestias assumenda dolores nesciunt quasi necessitatibus? Consequatur, eveniet! Inventore quidem assumenda voluptas obcaecati impedit a doloribus maxime ratione doloremque fugiat harum, tempora ab iure magni magnam totam sequi, iusto delectus eligendi eos distinctio dolorum culpa? Maxime provident quae, quis eligendi eos praesentium tenetur! Iure cupiditate tempore rerum corrupti magnam reprehenderit, unde ad ducimus aliquid dicta non nostrum officiis quis modi quod repellendus praesentium, voluptatibus laboriosam eveniet iusto voluptatum? Ab voluptate consectetur recusandae.
            </p>
        </div>
      </div>

      <Footer  ></Footer>
    </div>
  );
};

export default Infor;
