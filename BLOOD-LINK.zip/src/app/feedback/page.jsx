"use client";

import Footer from "@/components/Footer";
import Navbar from "@/components/Navbar";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardDescription,
  CardHeader,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useState } from "react";
import { db } from "../../../firebase";
import { addDoc, collection } from "firebase/firestore";
// import { db, collection, addDoc } from "@/lib/firebase"; // Import Firebase functions

const DonorsFeedback = () => {
  const [formData, setFormData] = useState({
    name: "",
    city: "",
    email: "",
    message: "",
  });
  const [message, setMessage] = useState("");

  // Handle input change
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Add form data to Firestore
      await addDoc(collection(db, "donorsFeedback"), formData);
      setMessage("Feedback submitted successfully!");
      setFormData({ name: "", city: "", email: "", message: "" });
    } catch (error) {
      setMessage("Error submitting feedback. Please try again.");
      console.error("Error:", error);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="flex justify-center items-center flex-col gap-10">
        <div className="flex item-center justify-center">
          <Card className="rounded mr-5 shadow-lg border-none bg-red-700 w-[200px] h-[140px] ">
            <CardHeader className="flex text-white">
              <CardDescription>
                <h2 className="text-lg">Rajesh Kumar</h2>
                <p>I loved the way this website works</p>
              </CardDescription>
            </CardHeader>
          </Card>
        </div>
        <div>
          <div className="w-[800px] m-auto">
            <h1 className="w-full text-center font-bold text-3xl text-red-700">
              Donors Feedback Form
            </h1>
            <form 
              onSubmit={handleSubmit} 
              className="text-red-700 flex flex-col items-center p-4 gap-4 border rounded border-red-700"
            >
              <Input
                name="name"
                value={formData.name}
                onChange={handleChange}
                placeholder="Enter Your Name"
                required
              />
              <Input
                name="city"
                value={formData.city}
                onChange={handleChange}
                placeholder="Enter Your City"
                required
              />
              <Input
                name="email"
                value={formData.email}
                onChange={handleChange}
                placeholder="Enter Your Email"
                type="email"
                required
              />
              <Textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                placeholder="Type your message here."
                required
              />
              <Button className="bg-red-700 text-white" type="submit">
                Submit
              </Button>
            </form>
            {message && <p className="text-center mt-3 text-green-600">{message}</p>}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default DonorsFeedback;
