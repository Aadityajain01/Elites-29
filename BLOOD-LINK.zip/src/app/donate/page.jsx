'use client';

import Footer from "@/components/Footer";
import Form from "@/components/Form";

const donorPage = () => {
  return (
    <div>
      <Form></Form>
      <Footer></Footer>
    </div>
  );
};

export default donorPage;
